"""
Szymon's Chomej
favourite song parameters
"""
artist = "Kwiat Jabłoni"   #Best Polish band :)
title = "Dziś Późno Pójdę Spać"
genre = "Alternative"
album = "Niemożliwe"
originCountry = "Poland"
releaseYear = 2019
durationsInSeconds = 232
youTubeViews = 22223205
mySonLikeIt = True

"""
My score in scale 1:10. 
When 1 is the worst and 10 is the best
"""
myScore = 9,5
